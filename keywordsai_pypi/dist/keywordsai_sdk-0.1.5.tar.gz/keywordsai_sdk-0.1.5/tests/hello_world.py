from keywordsai_sdk.core import KeywordsAI

import sys
print(sys.path)