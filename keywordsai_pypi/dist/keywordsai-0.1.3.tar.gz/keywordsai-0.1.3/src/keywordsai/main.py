def keywordsai_completion(*args, **kwargs):
    print("completion updated", args, kwargs)
    
    
