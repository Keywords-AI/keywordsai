from os import getenv

KEYWORDSAI_NUM_THREADS = getenv("KEYWORDSAI_NUM_THREADS", 1)
