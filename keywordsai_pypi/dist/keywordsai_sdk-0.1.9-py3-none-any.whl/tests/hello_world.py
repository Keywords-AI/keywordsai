from keywordsai_sdk.core import KeywordsAILogger

import sys
print(sys.path)