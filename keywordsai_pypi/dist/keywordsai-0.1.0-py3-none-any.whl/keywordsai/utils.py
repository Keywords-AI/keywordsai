def completion(*args, **kwargs):
    print("completion", args, kwargs)