# Keywords AI SDK
Keywords AI Python SDK allows you to easily interact with the Keywords AI API.

## Get started
You can install the current directory as a python package via this command
```
poetry install
```
or
```
pip install . -e
```